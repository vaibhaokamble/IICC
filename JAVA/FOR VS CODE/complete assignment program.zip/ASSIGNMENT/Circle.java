/* 4) Write a Java program to find the area of circle. */

package ASSIGNMENT;

public class Circle {
    public static void main(String[] args) 
    {
        int r=5;
        double pi = 3.14, area;
        area = pi * r * r;
        System.out.println("Area of circle = "+area);
    }            
}
