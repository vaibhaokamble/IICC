/* 2) Write a Java program to find the volume of two boxes. */

package ASSIGNMENT;

public class Vol2Box {
    public static void main(String[] args) {   
        double len1=10;
        double wid1=20;
        double hei1=30;
        double volume1 = len1 * wid1 * hei1; 
        System.out.println("the volume of box = " +volume1);

        double len2=50;
        double wid2=20;
        double hei2=40;
        double volume2 = len2 * wid2 * hei2; 
        System.out.println("the volume of box = " +volume2);
    }
}
