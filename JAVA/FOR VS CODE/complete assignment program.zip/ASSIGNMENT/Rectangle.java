/* 3) Write a Java program to find the area of rectangle. */

package ASSIGNMENT;

public class Rectangle {
    public static void main(String[] args) {
        int width=5;  
        int height=10;  
        int area=width*height;  
        System.out.println("the area of rectangle is = " +area); 
    }
}
