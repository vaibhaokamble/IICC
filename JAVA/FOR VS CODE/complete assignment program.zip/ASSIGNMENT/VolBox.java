/*1) Write a Java program to find the volume of box. */

package ASSIGNMENT;

public class VolBox {
    public static void main(String[] args) {   
        double length=10;
        double width=20;
        double height=30;
        double volume = length * width * height; 
        System.out.println("the volume of box = " +volume);
    }
    
}
